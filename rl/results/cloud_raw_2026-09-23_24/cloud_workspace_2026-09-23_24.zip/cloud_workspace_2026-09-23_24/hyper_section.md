
---

## Added 2026-09-24: how k3 uses Hyper Ray and Roar in Unison across all 1,000 table games

Counted by replaying every Hydreigon v Lucario game from the table (seeds 72,130,000–72,130,999) and checking the legal moves at each of Hydreigon's decisions. The replays reproduce the table (Hydreigon wins 302 of 1,000).

**The engine's card matches the real card.** The engine's text for Roar in Unison and Hyper Ray is word for word the Limitless card text (Hydreigon, B1 157). In play, all 1,251 uses of Roar in Unison did exactly what the text says: 2 Darkness Energy onto that Hydreigon, 30 damage to it, never twice by the same Hydreigon in a turn, and never using up the turn's normal Energy. No rules error found here.

**k3 fires Hyper Ray only when it knocks out the Active Pokémon.** Hyper Ray was available on 1,203 of Hydreigon's turns.

| Lucario's Active Pokémon | k3 used Hyper Ray | k3 ended the turn without it |
|---|---:|---:|
| 130 HP or less (Hyper Ray knocks it out) | 732 (99%) | 8 |
| more than 130 HP (almost always a healthy Mega Lucario ex, 190 HP) | 12 (3%) | 434 |

- In 343 of those 442 passes, Hydreigon itself had more than 60 HP, so it could have refilled with Roar in Unison the next turn. The passes aren't about protecting a Hydreigon too weak to use its ability.
- k3 does use the refill. On the Hydreigon turn right after a Hyper Ray, it used Roar in Unison 370 times out of 375 where it was usable (99%). Overall it used Roar in Unison on 83% of the turns it was usable without knocking Hydreigon out.
- The two-turn line a person would play against Mega Lucario ex (Hyper Ray for 130, refill, Hyper Ray again for the knockout and 3 points) is exactly the one k3 skips.
- Association only, not a measured effect: in the 338 games with at least one such pass, Hydreigon won 11.8%; in the other 662 it won 39.6%. Those games also tend to be the ones where a healthy Mega Lucario ex is already in front of Hydreigon, so the gap isn't all caused by the pass.
