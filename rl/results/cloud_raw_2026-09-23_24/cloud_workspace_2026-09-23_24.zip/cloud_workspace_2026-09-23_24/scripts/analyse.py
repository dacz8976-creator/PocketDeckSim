import json, math, sys, itertools, collections
S = sys.argv[1]
lim = json.load(open(f"{S}/lim/limitless_b4a_2026-09-23.json"))["cells"]
games = [json.loads(l) for l in open(f"{S}/k3table_games.jsonl")]
DECKS = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
def lk(a, b):
    if f"{a}|{b}" in lim: w, l, t = lim[f"{a}|{b}"]
    else: l, w, t = lim[f"{b}|{a}"]
    return w, l, t
sim = collections.defaultdict(lambda: [0, 0, 0])
for g in games:
    s = sim[g["pair"]]; s[{"a": 0, "b": 1, "draw": 2}[g["res"]]] += 1
rows = []
for a, b in itertools.combinations(DECKS, 2):
    sw, sl, sd = sim[f"{a}|{b}"]; ns = sw + sl + sd
    w, l, t = lk(a, b); nl = w + l + t
    ps = (sw + .5 * sd) / ns; pl = (w + .5 * t) / nl
    se = math.sqrt(pl * (1 - pl) / nl); ses = math.sqrt(ps * (1 - ps) / ns)
    pnd = sw / (sw + sl) if sw + sl else .5
    bo3 = pnd ** 2 * (3 - 2 * pnd)
    rows.append(dict(a=a, b=b, sim=ps, sim_n=ns, sim_draw=sd / ns, lim=pl, lim_n=nl, se=se, ses=ses, bo3=bo3))
def pearson(x, y):
    mx, my = sum(x) / len(x), sum(y) / len(y)
    sx = math.sqrt(sum((v - mx) ** 2 for v in x)); sy = math.sqrt(sum((v - my) ** 2 for v in y))
    return sum((u - mx) * (v - my) for u, v in zip(x, y)) / (sx * sy)
def ranks(v):
    o = sorted(range(len(v)), key=lambda i: v[i]); r = [0] * len(v)
    i = 0
    while i < len(o):
        j = i
        while j + 1 < len(o) and v[o[j + 1]] == v[o[i]]: j += 1
        for k in range(i, j + 1): r[o[k]] = (i + j) / 2
        i = j + 1
    return r
x = [r["sim"] for r in rows]; y = [r["lim"] for r in rows]
diff = [a - b for a, b in zip(x, y)]
mae = sum(abs(d) for d in diff) / len(diff)
rms = math.sqrt(sum(d * d for d in diff) / len(diff))
noise_var = sum(r["se"] ** 2 + r["ses"] ** 2 for r in rows) / len(rows)
mae_chance = sum(math.sqrt(2 / math.pi) * math.sqrt(r["se"] ** 2 + r["ses"] ** 2) for r in rows) / len(rows)
rms_true = math.sqrt(max(0, rms ** 2 - noise_var))
fav = [(r["sim"] > .5) == (r["lim"] > .5) for r in rows if r["sim"] != .5 and r["lim"] != .5]
clear = [r for r in rows if abs(r["lim"] - .5) > 1.96 * r["se"]]
fav_clear = [(r["sim"] > .5) == (r["lim"] > .5) for r in clear]
big = [r for r in rows if abs(r["sim"] - r["lim"]) > 1.96 * math.sqrt(r["se"] ** 2 + r["ses"] ** 2)]
inband = [r for r in rows if min(r["sim"], r["bo3"]) - 1.96 * r["se"] <= r["lim"] <= max(r["sim"], r["bo3"]) + 1.96 * r["se"]]
# deck level: unweighted mean over its 7 matchups
def deck_scores(key):
    out = {}
    for d in DECKS:
        v = []
        for r in rows:
            if r["a"] == d: v.append(r[key])
            elif r["b"] == d: v.append(1 - r[key])
        out[d] = sum(v) / len(v)
    return out
ds, dl = deck_scores("sim"), deck_scores("lim")
sp = pearson(ranks([ds[d] for d in DECKS]), ranks([dl[d] for d in DECKS]))
z = 0.5 * math.log((1 + sp) / (1 - sp)); h = 1.06 / math.sqrt(8 - 3)
ci = (math.tanh(z - 1.96 * h), math.tanh(z + 1.96 * h))
res = dict(matchup_r=pearson(x, y), avg_miss=mae, avg_miss_chance_only=mae_chance, rms=rms, rms_after_chance=rms_true,
           favored_agree=f"{sum(fav)}/{len(fav)}", clear_cells=len(clear), favored_agree_clear=f"{sum(fav_clear)}/{len(fav_clear)}",
           disagree_beyond_chance=len(big), lim_within_game_bo3_band=f"{len(inband)}/{len(rows)}",
           deck_rank_corr=sp, deck_rank_corr_95=ci, deck_sim=ds, deck_lim=dl, sim_games=len(games))
if "--rows" in sys.argv:
    for r in sorted(rows, key=lambda r: -abs(r["sim"] - r["lim"])):
        print(f'{r["a"]:>9} v {r["b"]:<9} sim {100*r["sim"]:5.1f} (bo3 {100*r["bo3"]:5.1f}, draws {100*r["sim_draw"]:4.1f}%, n {r["sim_n"]})  limitless {100*r["lim"]:5.1f} ±{196*r["se"]:4.1f} (n {r["lim_n"]})  diff {100*(r["sim"]-r["lim"]):+5.1f}')
print(json.dumps(res, indent=1, default=lambda v: round(v, 4) if isinstance(v, float) else v))
