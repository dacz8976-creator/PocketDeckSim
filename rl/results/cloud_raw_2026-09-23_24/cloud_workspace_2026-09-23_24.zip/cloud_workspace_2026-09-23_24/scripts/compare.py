import json, math, itertools, collections, sys
S = sys.argv[1]
lim = json.load(open(f"{S}/lim/limitless_b4a_2026-09-23.json"))["cells"]
D = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
def get(tab, a, b):
    if f"{a}|{b}" in tab: w, l, t = tab[f"{a}|{b}"]
    else: l, w, t = tab[f"{b}|{a}"]
    return w, l, t
def score(w, l, t): n = w + l + t; return (w + .5 * t) / n, n
new = collections.defaultdict(lambda: [0, 0, 0])
for line in open(f"{S}/k3table_games.jsonl"):
    g = json.loads(line); new[g["pair"]][{"a": 0, "b": 1, "draw": 2}[g["res"]]] += 1
tables = dict(json.load(open(f"{S}/oldtables.json"))); tables["rules4 (new)"] = dict(new)
def pearson(x, y):
    mx, my = sum(x)/len(x), sum(y)/len(y)
    return sum((u-mx)*(v-my) for u, v in zip(x, y)) / math.sqrt(sum((u-mx)**2 for u in x) * sum((v-my)**2 for v in y))
def ranks(v):
    o = sorted(range(len(v)), key=lambda i: v[i]); r = [0]*len(v); i = 0
    while i < len(o):
        j = i
        while j+1 < len(o) and v[o[j+1]] == v[o[i]]: j += 1
        for k in range(i, j+1): r[o[k]] = (i+j)/2
        i = j+1
    return r
for name, tab in tables.items():
    xs, ys, d2, nv, fav, favc, big = [], [], [], [], 0, [0, 0], 0
    for a, b in itertools.combinations(D, 2):
        ps, ns = score(*get(tab, a, b)); pl, nl = score(*get(lim, a, b))
        se2 = pl*(1-pl)/nl + ps*(1-ps)/ns
        xs.append(ps); ys.append(pl); d2.append((ps-pl)**2); nv.append(se2)
        fav += (ps > .5) == (pl > .5)
        if abs(pl-.5) > 1.96*math.sqrt(pl*(1-pl)/nl): favc[1] += 1; favc[0] += (ps > .5) == (pl > .5)
        big += abs(ps-pl) > 1.96*math.sqrt(se2)
    mae = sum(math.sqrt(v) for v in d2)/28; chance = sum(math.sqrt(2/math.pi)*math.sqrt(v) for v in nv)/28
    rms_true = math.sqrt(max(0, sum(d2)/28 - sum(nv)/28))
    def deck(tabf):
        out = []
        for d in D:
            v = [score(*get(tabf, d, o))[0] for o in D if o != d]; out.append(sum(v)/7)
        return out
    sp = pearson(ranks(deck(tab)), ranks(deck(lim)))
    print(f"{name:14} matchup r {pearson(xs, ys):.2f} | avg miss {100*mae:.1f} (chance alone {100*chance:.1f}) | real error after chance, RMS {100*rms_true:.1f} (~{100*rms_true*math.sqrt(2/math.pi):.1f} as avg miss) | favored side {fav}/28, clear cells {favc[0]}/{favc[1]} | beyond chance {big}/28 | deck rank r {sp:.2f}")
