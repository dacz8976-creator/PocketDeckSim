import json, time, sys
from pdl_rl_env import engine_play
S = sys.argv[1]; G = sys.argv[2]
rows = [json.loads(l) for l in open(G)]
have = {"06-mega-blaziken-tournament-list","altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"}
sel = [r for r in rows if set(r["decks"]) <= have][:40]
ok = 0; t0 = time.time()
for r in sel:
    d = [f"{S}/decks/{x}.txt" for x in r["decks"]]
    w, pts, turns = engine_play(d[0], d[1], r["seed"], tuple(r["players"]))
    same = (w == r["winner"] and list(pts) == r["points"] and turns == r["turns"])
    ok += same
    if not same: print("MISMATCH", r["seed"], r["decks"], (w, pts, turns), (r["winner"], r["points"], r["turns"]))
print(f"{ok}/{len(sel)} identical; {(time.time()-t0)/max(1,len(sel)):.2f}s/game")
