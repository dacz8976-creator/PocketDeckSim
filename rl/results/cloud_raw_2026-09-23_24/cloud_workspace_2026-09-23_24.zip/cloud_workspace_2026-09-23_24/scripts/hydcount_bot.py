# Hyper Ray / Roar in Unison behaviour of k3's Hydreigon across the 1,000 table games (seeds 72,130,000-72,130,999).
import json, sys, os, multiprocessing as mp
S = os.path.dirname(os.path.abspath(__file__))
BOT = os.environ.get("BOT", "k3")
H, L = f"{S}/decks/hydreigon.txt", f"{S}/decks/lucario.txt"
def mv_kind(s):
    m = json.loads(s)
    if isinstance(m, str): return m, None
    k = list(m)[0]; return k, m[k]
def game(i):
    from pdl_rl_env import RawEnv
    seed = 72_130_000 + i; hs = 0 if i % 2 == 0 else 1
    d = (H, L) if hs == 0 else (L, H)
    ids = sorted(set(RawEnv.deck_card_ids(H)) | set(RawEnv.deck_card_ids(L)))
    env = RawEnv(ids, "v2.2"); env.set_recording(True)
    env.reset(d[0], d[1], seed, [BOT, BOT]); rec = env.history(); res = env.result()
    env.reset(d[0], d[1], seed, None)
    turns = {}  # turn -> record
    viol = []
    while not env.done:
        applied = env.history(); nxt = rec[len(applied)]
        v = json.loads(env.describe(hs)); me, op = v["me"], v["them"]
        legal = env.legal_actions_json()
        if v["current_player"] == hs and v["turn"] > 0:
            t = turns.setdefault(v["turn"], {"hyper_legal": False, "hyper_used": False, "declined_end": False, "decline_opp_hp": None,
                                              "decline_hyd_hp": None, "roar_legal": 0, "roar_used": 0, "roar_legal_selfko": 0, "roar_idx_used": []})
            kinds = [mv_kind(m) for m in legal]
            hyper = any(k == "Attack" and x["title"] == "Hyper Ray" for k, x in kinds)
            roar_idx = [x["in_play_idx"] for k, x in kinds if k == "UseAbility" and me["board"][x["in_play_idx"]] and me["board"][x["in_play_idx"]]["name"] == "Hydreigon"]
            t["hyper_legal"] |= hyper
            ck, cx = mv_kind(nxt[2])
            if hyper and ck == "EndTurn":
                t["declined_end"] = True; t["decline_opp_hp"] = op["board"][0]["hp_left"] if op["board"][0] else None
                t["decline_hyd_hp"] = me["board"][0]["hp_left"]
                t["decline_opp_name"] = op["board"][0]["name"] if op["board"][0] else None
            if roar_idx:
                t["roar_legal"] = max(t["roar_legal"], len(roar_idx))
                if all(me["board"][j]["hp_left"] <= 30 for j in roar_idx): t["roar_legal_selfko"] = 1
                if any(me["board"][j]["hp_left"] > 30 for j in roar_idx): t["roar_legal_healthy"] = 1
            if ck == "Attack" and cx["title"] == "Hyper Ray":
                t["hyper_used"] = True
                t["use_opp_hp"] = op["board"][0]["hp_left"] if op["board"][0] else None
                t["use_opp_name"] = op["board"][0]["name"] if op["board"][0] else None
                t["use_hyd_hp"] = me["board"][0]["hp_left"]
            before = me["board"]; en_now = me["energy_now"]
            if ck == "UseAbility" and before[cx["in_play_idx"]] and before[cx["in_play_idx"]]["name"] == "Hydreigon":
                j = cx["in_play_idx"]
                if j in t["roar_idx_used"]: viol.append(("reused", seed, v["turn"], j))
                t["roar_used"] += 1; t["roar_idx_used"].append(j)
        idx = [k for k, m in enumerate(legal) if m == nxt[2]][0]
        pre = json.loads(env.describe(hs))
        env.step(idx)
        # check Roar / Hyper Ray effects right after the chosen move (forced follow-ups may add more; compare conservatively)
        if pre["current_player"] == hs:
            ck, cx = mv_kind(nxt[2]); post = json.loads(env.describe(hs))
            if ck == "UseAbility" and pre["me"]["board"][cx["in_play_idx"]]["name"] == "Hydreigon":
                j = cx["in_play_idx"]; b, a = pre["me"]["board"][j], post["me"]["board"][j]
                if a is None:
                    pass  # knocked itself out (should only happen at <=30 HP)
                else:
                    de = len(a["energy"]) - len(b["energy"]); dh = b["hp_left"] - a["hp_left"]
                    if not (de == 2 and dh == 30 and a["energy"].count("Darkness") - b["energy"].count("Darkness") == 2):
                        viol.append(("roar_effect", seed, pre["turn"], de, dh))
                if post["me"]["energy_now"] != pre["me"]["energy_now"]:
                    viol.append(("roar_used_turn_energy", seed, pre["turn"]))
            if ck == "Attack" and cx["title"] == "Hyper Ray":
                a = post["me"]["board"][0] if post["current_player"] == hs else None
    w, pts, tn = env.result()
    assert (w, list(pts), tn) == (res[0], list(res[1]), res[2])
    hyd_won = (w == hs)
    return {"seed": seed, "hyd_won": hyd_won, "turns": turns, "viol": viol}
if __name__ == "__main__":
    with mp.get_context("spawn").Pool(2) as pool:
        out = pool.map(game, range(1000), chunksize=10)
    json.dump(out, open(f"{S}/hydcount_{BOT}.json", "w"))
    print("games", len(out), "hydreigon wins", sum(g["hyd_won"] for g in out))
