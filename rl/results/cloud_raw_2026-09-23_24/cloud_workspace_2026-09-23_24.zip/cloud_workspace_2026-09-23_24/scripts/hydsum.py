# Summarise Hyper Ray / Roar counts from hydcount_*.json files. Usage: hydsum.py label=file[:n] ...
import json, collections, sys
for arg in sys.argv[1:]:
    name, spec = arg.split("=", 1); f, _, n = spec.partition(":")
    G = json.load(open(f)); G = G[:int(n)] if n else G
    R = [r for g in G for r in g["turns"].values() if r["hyper_legal"]]
    tab = collections.defaultdict(lambda: [0, 0])
    for r in R:
        if r["hyper_used"]: hp = r.get("use_opp_hp"); tab["ko" if hp is not None and hp <= 130 else "noko"][0] += 1
        elif r["declined_end"]: hp = r.get("decline_opp_hp"); tab["ko" if hp is not None and hp <= 130 else "noko"][1] += 1
    T = [r for g in G for r in g["turns"].values()]
    h = [r for r in T if r.get("roar_legal_healthy")]
    print(f"{name}: Hydreigon wins {sum(g['hyd_won'] for g in G)}/{len(G)} | KO-able: used {tab['ko'][0]} passed {tab['ko'][1]} | not KO-able: used {tab['noko'][0]} passed {tab['noko'][1]} ({100*tab['noko'][0]/max(1,sum(tab['noko'])):.0f}% used) | Roar used {sum(1 for r in h if r['roar_used'])}/{len(h)} | flagged {sum(len(g['viol']) for g in G)}")
