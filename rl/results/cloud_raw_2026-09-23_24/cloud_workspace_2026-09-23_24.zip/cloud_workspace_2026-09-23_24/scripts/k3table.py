# k3 vs k3 table on rules4 / add-on 0.7.2, 28 pairings of the Sept 8 meta lists.
# Seeds: 72,000,000 + pair_index*10,000 + i, i < N; even i -> first deck in seat 0, odd -> seat 1.
import json, sys, os, itertools, multiprocessing as mp
S = os.path.dirname(os.path.abspath(__file__))
DECKS = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
PAIRS = list(itertools.combinations(DECKS, 2))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
OUT = f"{S}/k3table_games.jsonl"
def play(t):
    from pdl_rl_env import engine_play
    k, a, b, i = t
    seed = 72_000_000 + k*10_000 + i
    seat_a = i % 2
    d = (a, b) if seat_a == 0 else (b, a)
    w, pts, turns = engine_play(f"{S}/decks/{d[0]}.txt", f"{S}/decks/{d[1]}.txt", seed, ("k3","k3"))
    res = "draw" if w == -1 else ("a" if w == seat_a else "b")
    return {"pair": f"{a}|{b}", "seed": seed, "seat_a": seat_a, "res": res, "points": list(pts), "turns": turns}
if __name__ == "__main__":
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT): done.add(json.loads(l)["seed"])
    tasks = [(k, a, b, i) for k, (a, b) in enumerate(PAIRS) for i in range(N) if 72_000_000 + k*10_000 + i not in done]
    # interleave pairs so partial results cover every pairing
    tasks.sort(key=lambda t: (t[3], t[0]))
    with open(OUT, "a") as f, mp.get_context("spawn").Pool(2) as pool:
        for r in pool.imap_unordered(play, tasks, chunksize=8):
            f.write(json.dumps(r) + "\n"); f.flush()
    print("done")
