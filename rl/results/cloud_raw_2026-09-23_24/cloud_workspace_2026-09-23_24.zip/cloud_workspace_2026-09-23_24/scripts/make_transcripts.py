import os, sys, json, itertools
S = "/tmp/claude-0/-home-claude/fbbdfe94-57fd-539f-9713-2f618ca91542/scratchpad"; sys.path.insert(0, S); os.chdir(S)
import transcribe as T
games = [(72130002, 0), (72130003, 1), (72130005, 1), (72130007, 1), (72130008, 0)]
out = []
for n, (seed, seat_h) in enumerate(games, 1):
    if seat_h == 0: d = ("decks/hydreigon.txt", "decks/lucario.txt"); names = {0: "Hydreigon", 1: "Lucario"}
    else: d = ("decks/lucario.txt", "decks/hydreigon.txt"); names = {0: "Lucario", 1: "Hydreigon"}
    lines, (w, pts, turns) = T.transcript(d[0], d[1], seed, names)
    first = next(l for l in lines if l.startswith("\n**Turn 1")).split("— ")[1].split("**")[0]
    hp, lp = (pts[0], pts[1]) if seat_h == 0 else (pts[1], pts[0])
    out.append(f"\n---\n\n## Game {n}: seed {seed}. {first} goes first. Lucario wins {lp}–{hp} on turn {turns}.")
    out += lines
    out.append(f"\n**Game over:** Lucario {lp}, Hydreigon {hp}, after turn {turns}.")
json.dump({"lines": out, "gloss": {k: v for k, v in T.GLOSS.items()}}, open("transcripts_raw.json", "w"), ensure_ascii=False)
print(len(out), "lines;", len(T.GLOSS), "glossary cards")
for l in out:
    if l.startswith("\n---") or l.startswith("\n## "): pass
print("\n".join(l for l in out if l.startswith("\n## ")))
