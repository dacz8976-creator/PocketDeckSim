# Replays table games with a given compiled module and compares winner/points/turns.
import sys, json, itertools
moddir, n = sys.argv[1], int(sys.argv[2]); sys.path.insert(0, moddir)
import pdl_rl_env; from pdl_rl_env import engine_play
assert pdl_rl_env.__file__.startswith(moddir), pdl_rl_env.__file__
S = "/tmp/claude-0/-home-claude/fbbdfe94-57fd-539f-9713-2f618ca91542/scratchpad"
rows = [json.loads(l) for l in open(f"{S}/k3table_games.jsonl")]
seen, pick = {}, []
for r in rows:
    if seen.get(r["pair"], 0) < n: seen[r["pair"]] = seen.get(r["pair"], 0) + 1; pick.append(r)
ok = 0
for r in pick:
    a, b = r["pair"].split("|"); d = (a, b) if r["seat_a"] == 0 else (b, a)
    w, pts, t = engine_play(f"{S}/decks/{d[0]}.txt", f"{S}/decks/{d[1]}.txt", r["seed"], ("k3", "k3"))
    res = "draw" if w == -1 else ("a" if w == r["seat_a"] else "b")
    same = (res, list(pts), t) == (r["res"], r["points"], r["turns"]); ok += same
    if not same: print("MISMATCH", r["seed"], r["pair"])
print(f"{ok}/{len(pick)} table games identical with {pdl_rl_env.__file__}")
