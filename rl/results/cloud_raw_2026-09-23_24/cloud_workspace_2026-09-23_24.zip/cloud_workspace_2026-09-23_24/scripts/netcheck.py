import sys, json; sys.path.insert(0, sys.argv[1]); S = sys.argv[1]
from netplay import Match
U = sys.argv[2]
rows = [json.loads(l) for l in open(sys.argv[3])]
m = Match({"blaziken": f"{S}/decks/06-mega-blaziken-tournament-list.txt", "lucario": f"{S}/decks/lucario.txt"})
ck = {"ckpt_250k": {"blaziken": f"{S}/nets/ckpt_250k_blaziken.npz"}, "ckpt_300k": {"lucario": f"{S}/nets/ckpt_300k_lucario.npz"}}
ok = 0
for r in rows:
    net_deck = r["tag"].split(">")[0]
    pil = ["k3", "k3"]; pil[r["bot_seat"]] = ck[r["ckpt"]][net_deck]
    got = m.play(r["seed"], r["decks"][0], r["decks"][1], pil)
    same = got == (r["winner"], r["points"], r["turns"]); ok += same
    if not same: print("MISMATCH", r["seed"], got, (r["winner"], r["points"], r["turns"]))
print(f"{ok}/{len(rows)} identical")
