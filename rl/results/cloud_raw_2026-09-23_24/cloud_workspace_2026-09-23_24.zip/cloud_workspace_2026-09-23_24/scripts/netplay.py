# Plays network/k3 games with run 5's exact rules: env vocab = the run's pool decks, argmax with seeded tie-break.
import os, sys, numpy as np
os.environ.setdefault("OMP_NUM_THREADS", "1"); os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
S = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, S)
from model import MLP
from pdl_env import PocketEnv
HIDDEN = (512, 256)
def load_scorer(path, dim):
    net = MLP(dim, HIDDEN, seed=0); z = np.load(path)
    for i, p in enumerate(net.W + net.b): p[...] = z[f"p{i}"]
    return net
def pick(q, rng):
    if not np.isfinite(q).all(): raise RuntimeError("non-finite")
    best = np.flatnonzero(q == q.max())
    return int(best[0]) if len(best) == 1 else int(rng.choice(best))
class Match:
    def __init__(self, pool_paths):  # pool_paths: {deck: path} exactly as the run's settings
        self.paths = pool_paths
        self.env = PocketEnv(vocab_deck_paths=list(pool_paths.values()), features="v2.2")
        ps = list(pool_paths.values()); self.env.reset(ps[0], ps[1], 1)
        self.dim = self.env.obs_dim + self.env.action_dim
        self.nets = {}
    def net(self, path):
        if path not in self.nets: self.nets[path] = load_scorer(path, self.dim)
        return self.nets[path]
    def play(self, seed, d0, d1, pilots):
        """pilots: per seat, "k3" or a weights path."""
        rng = np.random.default_rng(seed); env = self.env
        bots = [p if p == "k3" else None for p in pilots]
        env.reset(self.paths[d0], self.paths[d1], seed, bots=bots)
        while not env.done:
            p = env.current_player
            obs, feats = env.observe(p), env.action_features()
            env.step(pick(self.net(pilots[p]).score_actions(obs, feats), rng))
        w, pts, turns = env.result()
        return w, list(pts), turns
