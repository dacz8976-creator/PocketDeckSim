import json, math, collections
S = "/tmp/claude-0/-home-claude/fbbdfe94-57fd-539f-9713-2f618ca91542/scratchpad"
lim = json.load(open(f"{S}/lim/limitless_b4a_2026-09-23.json"))["cells"]
tab = {json.loads(l)["seed"]: json.loads(l) for l in open(f"{S}/k3table_games.jsonl")}
G = [json.loads(l) for l in open(f"{S}/omni/omni_games.jsonl")]
by = collections.defaultdict(dict)
for g in G: by[(g["pair"], g["arm"])][g["seed"]] = g["res"]
sc = lambda r: 1.0 if r == "a" else (0.5 if r == "draw" else 0.0)
def L(pair):
    a, b = pair.split("|")
    if pair in lim: w, l, t = lim[pair]
    else: l, w, t = lim[f"{b}|{a}"]
    n = w + l + t; p = (w + .5*t)/n; return p, 1.96*math.sqrt(p*(1-p)/n)
arms = [a for a in ("blind", "hand", "full", "fullA", "fullB", "list", "listA") if any(k[1] == a for k in by)]
miss = collections.defaultdict(list)
for pair in sorted({k[0] for k in by}):
    pl, hl = L(pair)
    base = by.get((pair, "blind"), {})
    line = f"{pair:20} Limitless {100*pl:5.1f} ±{100*hl:4.1f} |"
    seeds_all = set.intersection(*[set(by[(pair, a)]) for a in arms if (pair, a) in by])
    k3 = sum(sc(tab[s]["res"]) for s in seeds_all) / len(seeds_all)
    line += f" k3 {100*k3:5.1f} (n {len(seeds_all)}) |"; miss["k3"].append(abs(k3 - pl))
    for a in [a for a in arms if (pair, a) in by]:
        d = by[(pair, a)]; v = [sc(d[s]) for s in seeds_all]; m = sum(v)/len(v)
        diff = [sc(d[s]) - sc(tab[s]["res"]) for s in seeds_all]; md = sum(diff)/len(diff)
        sd = math.sqrt(sum((x-md)**2 for x in diff)/(len(diff)-1)) if len(diff) > 1 else 0
        line += f" {a} {100*m:5.1f} ({100*md:+5.1f} ±{196*sd/math.sqrt(len(diff)):.1f} vs k3) |"
        miss[a].append(abs(m - pl))
    print(line)
print("average miss over these pairings:", {a: round(100*sum(v)/len(v), 1) for a, v in miss.items()})
