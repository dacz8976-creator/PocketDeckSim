# DIAGNOSTIC ONLY - "see everything" test (cheating bots). Never cite these numbers in a ranking.
# Same deals as the Sept 23 k3 table: seed 72,000,000 + pairing*10,000 + i; even i = first deck in seat 0.
import sys, os, json, itertools, multiprocessing as mp
S = "/tmp/claude-0/-home-claude/fbbdfe94-57fd-539f-9713-2f618ca91542/scratchpad"
MOD = os.environ.get("MOD", f"{S}/omni/mod-open")
DECKS = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
PAIRS = list(itertools.combinations(DECKS, 2))
FIVE = [("altaria","blaziken"), ("altaria","lucario"), ("blaziken","sceptile"), ("hydreigon","lucario"), ("sceptile","vespiquen")]
ARMS = sys.argv[1].split(","); N = int(sys.argv[2])
OUT = f"{S}/omni/omni_games.jsonl"
def play(t):
    sys.path.insert(0, MOD)
    from pdl_rl_env import engine_play
    arm, k, i = t
    a, b = PAIRS[k]; seed = 72_000_000 + k*10_000 + i; seat_a = i % 2
    d = (a, b) if seat_a == 0 else (b, a)
    env = {"blind": None, "hand": "hand:0,1", "full": "full:0,1",
           "fullA": f"full:{seat_a}", "fullB": f"full:{1 - seat_a}",
           "list": "list:0,1", "listA": f"list:{seat_a}", "listB": f"list:{1 - seat_a}"}[arm]
    if env: os.environ["PDL_OPEN_INFO"] = env
    else: os.environ.pop("PDL_OPEN_INFO", None)
    w, pts, turns = engine_play(f"{S}/decks/{d[0]}.txt", f"{S}/decks/{d[1]}.txt", seed, ("kr3", "kr3"))
    res = "draw" if w == -1 else ("a" if w == seat_a else "b")
    return {"arm": arm, "pair": f"{a}|{b}", "seed": seed, "seat_a": seat_a, "res": res, "points": list(pts), "turns": turns}
if __name__ == "__main__":
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT): r = json.loads(l); done.add((r["arm"], r["seed"]))
    ks = [PAIRS.index(p) for p in FIVE if not os.environ.get("ONLY") or "|".join(p) == os.environ["ONLY"]]
    tasks = [(arm, k, i) for i in range(N) for k in ks for arm in ARMS if (arm, 72_000_000 + k*10_000 + i) not in done]
    with open(OUT, "a") as f, mp.get_context("spawn").Pool(2) as pool:
        for r in pool.imap_unordered(play, tasks, chunksize=2):
            f.write(json.dumps(r) + "\n"); f.flush()
    print("done")
