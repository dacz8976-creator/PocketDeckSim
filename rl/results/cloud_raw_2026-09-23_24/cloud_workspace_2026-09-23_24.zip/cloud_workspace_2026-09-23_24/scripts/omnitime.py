import sys, os, time, json
sys.path.insert(0, sys.argv[1]); from pdl_rl_env import engine_play
S = "/tmp/claude-0/-home-claude/fbbdfe94-57fd-539f-9713-2f618ca91542/scratchpad"
H, L = f"{S}/decks/hydreigon.txt", f"{S}/decks/lucario.txt"
for code, mode in (("k3", ""), ("kr3", ""), ("kr3", "hand:0,1"), ("kr3", "full:0,1")):
    if mode: os.environ["PDL_OPEN_INFO"] = mode
    else: os.environ.pop("PDL_OPEN_INFO", None)
    t0 = time.time(); res = []
    for i in range(6):
        d = (H, L) if i % 2 == 0 else (L, H)
        res.append(engine_play(d[0], d[1], 72_130_000 + i, (code, code)))
    print(f"{code:4} {mode or 'blind':9} {(time.time()-t0)/6:.2f}s/game", res)
