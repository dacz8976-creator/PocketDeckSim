# Re-play the first N list/listA rows (file order) with the fixed module and compare.
import json, sys, os, multiprocessing as mp
sys.argv = [sys.argv[0], "list", "1"] + sys.argv[1:]
import omnirun
S = omnirun.S
if __name__ == "__main__":
    N = int(sys.argv[3])
    R = [json.loads(l) for l in open(f"{S}/omni/omni_games.jsonl")]
    R = [r for r in R if r["arm"] in ("list", "listA")][:N]
    tasks = [(r["arm"], omnirun.PAIRS.index(tuple(r["pair"].split("|"))), r["seed"] - 72_000_000 - omnirun.PAIRS.index(tuple(r["pair"].split("|")))*10_000) for r in R]
    with mp.get_context("spawn").Pool(2) as pool:
        out = pool.map(omnirun.play, tasks, chunksize=2)
    print("identical", sum(a == b for a, b in zip(out, R)), "of", len(R))
