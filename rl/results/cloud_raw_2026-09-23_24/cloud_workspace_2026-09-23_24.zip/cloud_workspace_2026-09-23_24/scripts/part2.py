# Part 2: k3/k3 and network/network on the same fresh seeds (73,000,000+), 2,000 games per row.
# pairing 0 = blaziken|lucario (step 0 networks), pairing 1 = weezing|lucario (stage 1 networks).
# game i: first-named deck in seat 0 when i is even, seat 1 when odd.
import sys, json, os, multiprocessing as mp
S = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, S)
N = 2000
ROWS = sys.argv[1].split(",") if len(sys.argv) > 1 else ["k3k3", "netnet"]
CFG = json.load(open(f"{S}/part2_cfg.json"))  # {"pairs":[{"a":..,"b":..,"pool":{deck:path},"nets":{deck:path}}]}
OUT = f"{S}/part2_games.jsonl"
_M = {}
def play(t):
    from netplay import Match
    k, i, row = t
    P = CFG["pairs"][k]; a, b = P["a"], P["b"]
    if k not in _M: _M[k] = Match(P["pool"])
    seed = 73_000_000 + k * 10_000 + i
    d = (a, b) if i % 2 == 0 else (b, a)
    use = {"k3k3": set(), "netnet": {a, b}, "anet": {a}, "bnet": {b}}[row]
    pil = [P["nets"][x] if x in use else "k3" for x in d]
    w, pts, turns = _M[k].play(seed, d[0], d[1], pil)
    seat_a = d.index(a)
    res = "draw" if w == -1 else ("a" if w == seat_a else "b")
    return {"pair": f"{a}|{b}", "row": row, "seed": seed, "seat_a": seat_a, "res": res, "points": pts, "turns": turns}
if __name__ == "__main__":
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT):
            r = json.loads(l); done.add((r["seed"], r["row"]))
    tasks = [(k, i, row) for k in range(len(CFG["pairs"])) for i in range(N) for row in ROWS
             if (73_000_000 + k * 10_000 + i, row) not in done]
    with open(OUT, "a") as f, mp.get_context("spawn").Pool(2) as pool:
        for r in pool.imap_unordered(play, tasks, chunksize=16):
            f.write(json.dumps(r) + "\n"); f.flush()
    print("done")
