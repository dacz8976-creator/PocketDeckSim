import json, sys, os
S = os.path.dirname(os.path.abspath(__file__))
from pdl_rl_env import RawEnv
H, L = f"{S}/decks/hydreigon.txt", f"{S}/decks/lucario.txt"
for seed, turn in [(72130214, 10), (72130221, 7), (72130397, 5)]:
    i = seed - 72130000; hs = 0 if i % 2 == 0 else 1; d = (H, L) if hs == 0 else (L, H)
    ids = sorted(set(RawEnv.deck_card_ids(H)) | set(RawEnv.deck_card_ids(L)))
    os.environ["PDL_OPEN_INFO"] = f"list:{hs}"
    env = RawEnv(ids, "v2.2"); env.set_recording(True); env.reset(d[0], d[1], seed, ["kr3", "kr3"]); rec = env.history()
    os.environ.pop("PDL_OPEN_INFO")
    env.reset(d[0], d[1], seed, None)
    while not env.done:
        nxt = rec[len(env.history())]; v = json.loads(env.describe(hs))
        legal = env.legal_actions_json(); idx = [k for k, m in enumerate(legal) if m == nxt[2]][0]
        if v["turn"] == turn and v["current_player"] == hs:
            b = [(j, p["name"], p["hp_left"], len(p["energy"])) for j, p in enumerate(v["me"]["board"]) if p]
            print(seed, "move", nxt[2][:80], "| board", b)
        env.step(idx)
        if v["turn"] > turn: break
    print("---")
