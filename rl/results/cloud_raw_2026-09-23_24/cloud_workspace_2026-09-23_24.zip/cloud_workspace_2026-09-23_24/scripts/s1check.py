import sys; S = sys.argv[1]; sys.path.insert(0, S)
from netplay import Match
ref = """83000186 w 0 1 [1, 3] 9 w
83000187 l 1 1 [2, 4] 8 w
83000188 w 0 1 [0, 4] 6 w
83000189 l 1 1 [1, 3] 8 w
83000190 w 0 0 [2, 0] 5 w
83000191 l 1 0 [4, 0] 6 w
83000192 w 0 1 [1, 3] 7 w
83000193 l 1 1 [0, 2] 7 w
83050000 l 0 0 [4, 2] 9 l
83050001 w 1 0 [2, 0] 7 l
83050002 l 0 0 [4, 1] 10 l
83050003 w 1 0 [1, 0] 3 l
83050004 l 0 1 [0, 3] 8 l
83050005 w 1 1 [0, 4] 7 l
83050006 l 0 0 [4, 2] 10 l
83050007 w 1 1 [2, 4] 9 l"""
m = Match({"weezing": f"{S}/decks/weezing.txt", "lucario": f"{S}/decks/lucario.txt"})
net = {"w": f"{S}/nets/ckpt_1800k_avg_weezing.npz", "l": f"{S}/nets/ckpt_1800k_avg_lucario.npz"}
full = {"w": "weezing", "l": "lucario"}
ok = 0
for line in ref.splitlines():
    p = line.split(); seed = int(p[0]); first = p[1]; seat = int(p[2]); w = int(p[3])
    pts = [int(p[4].strip("[,")), int(p[5].strip("],"))]; turns = int(p[6]); nd = p[7]
    d0 = full[first]; d1 = "lucario" if d0 == "weezing" else "weezing"
    pil = ["k3", "k3"]; pil[seat] = net[nd]
    got = m.play(seed, d0, d1, pil); same = got == (w, pts, turns); ok += same
    if not same: print("MISMATCH", seed, got, (w, pts, turns))
print(f"{ok}/16 identical")
