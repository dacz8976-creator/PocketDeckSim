# Seconds per game on one core: k3 v k3, kr3 v kr3 blind, kr3 v kr3 guessing from the list (symmetric). Same deals as the table.
import sys, os, time, json, itertools
sys.path.insert(0, f"{os.path.dirname(os.path.abspath(__file__))}/omni/mod-open2")
from pdl_rl_env import engine_play
S = os.path.dirname(os.path.abspath(__file__))
DECKS = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
PAIRS = list(itertools.combinations(DECKS, 2))
FIVE = [("altaria","blaziken"), ("altaria","lucario"), ("blaziken","sceptile"), ("hydreigon","lucario"), ("sceptile","vespiquen")]
N = int(sys.argv[1]); out = {}
for name, bots, env in (("k3", ("k3","k3"), None), ("kr3 blind", ("kr3","kr3"), None), ("kr3 list", ("kr3","kr3"), "list:0,1")):
    if env: os.environ["PDL_OPEN_INFO"] = env
    else: os.environ.pop("PDL_OPEN_INFO", None)
    for p in FIVE:
        k = PAIRS.index(p); t0 = time.perf_counter(); turns = 0
        for i in range(N):
            a, b = p; d = (a, b) if i % 2 == 0 else (b, a)
            w, pts, t = engine_play(f"{S}/decks/{d[0]}.txt", f"{S}/decks/{d[1]}.txt", 72_000_000 + k*10_000 + i, bots); turns += t
        out[(name, "|".join(p))] = ((time.perf_counter() - t0) / N, turns / N)
        print(f"{name:10} {'|'.join(p):20} {out[(name,'|'.join(p))][0]:6.2f} s/game  {turns/N:5.1f} turns", flush=True)
