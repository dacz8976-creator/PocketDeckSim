# Readable k3 v k3 transcripts: record the game with both seats k3, then replay it move by move
# (no bots) so both real hands can be shown at every turn. Replay must reproduce the recorded result.
import json, collections, sys
from pdl_rl_env import RawEnv
GLOSS = {}
NAMES = {"hydreigon": "Hydreigon", "lucario": "Lucario"}
def card_name(obj):
    if isinstance(obj, dict):
        for k in ("Pokemon", "Trainer"):
            if k in obj: return obj[k]["name"]
        if "name" in obj: return obj["name"]
    return str(obj)
def mon(b):
    if b is None: return None
    s = f'{b["name"]} {b["hp_left"]}/{b["hp_card"]} HP'
    if b["energy"]: s += " [" + ", ".join(b["energy"]) + "]"
    if b["tools"]: s += " +" + ", ".join(card_name(t) for t in b["tools"])
    if b["status"]: s += " (" + ", ".join(b["status"]) + ")"
    return s
def board_line(side):
    bd = side["board"]; act = mon(bd[0]) or "none"
    bench = [mon(x) for x in bd[1:] if x is not None]
    return f"Active {act}; Bench: " + ("; ".join(bench) if bench else "empty")
def views(env):
    v = json.loads(env.describe(0))  # seat 0 as "me", seat 1 as "them"
    return {0: v["me"], 1: v["them"]}, v
def slot(side, idx):
    b = side["board"][idx]; return (b["name"] if b else "?") + (" (Active)" if idx == 0 else " (Bench)")
def describe_move(mv, p, before, deckname):
    m = json.loads(mv); me = before[p]; op = before[1 - p]
    if m == "EndTurn": return "ends the turn"
    k = list(m)[0]; x = m[k]
    if k == "DrawCard": return f"draws {x['amount']} card" + ("s" if x["amount"] > 1 else "")
    if k == "Place": return f"puts {card_name(x[0])} into play ({'Active' if x[1] == 0 else 'Bench'})"
    if k == "Play": return f"plays {x['trainer_card']['name']}"
    if k == "Attach":
        parts = [f"{n} {t} Energy to {slot(me, i)}" for n, t, i in x["attachments"]]
        return "attaches " + ", ".join(parts) + (" (turn's Energy)" if x.get("is_turn_energy") else "")
    if k == "AttachTool": return f"attaches {card_name(x['tool_card'])} to {slot(me, x['in_play_idx'])}"
    if k == "Evolve": return f"evolves {slot(me, x['in_play_idx']) if 'in_play_idx' in x else '?'} into {card_name(x['evolution'])}" if 'in_play_idx' in x else f"evolves into {card_name(x['evolution'])}"
    if k == "Attack": return f"attacks with {x['title']} ({x['fixed_damage']} base; {x['effect'] or 'no text'})"
    if k == "Retreat": return f"retreats Active, bringing up {slot(me, x)}"
    if k == "UseAbility": return f"uses the Ability of {slot(me, x['in_play_idx'])}"
    if k == "Promote": return f"promotes {slot(before[x['player']], x['in_play_idx'])} to Active"
    if k == "Activate": return f"chooses {slot(before[x['player']], x['in_play_idx'])} to become Active"
    if k == "Heal": return f"heals {x['amount']} from {slot(me, x['in_play_idx'])}" + (" and cures status" if x.get("cure_status") else "")
    if k == "DiscardToolFromPokemon": return f"discards a Tool from {slot(before[x['player']], x['in_play_idx'])}"
    if k == "DiscardOpponentSupporter": return f"discards opponent's {card_name(x['supporter_card'])} from their hand"
    if k == "ApplyDamage": return "puts damage: " + ", ".join(f"{d} to {slot(before[pl], i)}" for d, pl, i in x["targets"])
    if k == "ResolveAttackRetaliation": return "(engine step: after-attack effects)"
    return f"{k} {json.dumps(x)[:160]}"
def changes(before, after, names):
    out = []
    for s in (0, 1):
        b, a = before[s]["board"], after[s]["board"]
        for i in range(4):
            if b[i] and a[i] and b[i]["name"] == a[i]["name"]:
                if a[i]["hp_left"] != b[i]["hp_left"]:
                    out.append(f"{names[s]}'s {a[i]['name']} {b[i]['hp_left']} → {a[i]['hp_left']} HP")
                if a[i]["status"] != b[i]["status"]:
                    out.append(f"{names[s]}'s {a[i]['name']} status {b[i]['status'] or 'none'} → {a[i]['status'] or 'none'}")
        bn = collections.Counter(x["name"] for x in b if x); an = collections.Counter(x["name"] for x in a if x)
        gone = bn - an
        if gone and before[s]["points"] is not None:
            pass
        if after[1 - s]["points"] != before[1 - s]["points"] and gone:
            out.append(f"{names[s]}'s {', '.join(gone.elements())} knocked out")
        if after[s]["points"] != before[s]["points"]:
            out.append(f"{names[s]} points {before[s]['points']} → {after[s]['points']}")
    return out
def transcript(deck0, deck1, seed, names):
    ids = sorted(set(RawEnv.deck_card_ids(deck0)) | set(RawEnv.deck_card_ids(deck1)))
    env = RawEnv(ids, "v2.2"); env.set_recording(True)
    env.reset(deck0, deck1, seed, ["k3", "k3"]); rec = env.history(); res = env.result()
    env.reset(deck0, deck1, seed, None)
    lines, cur_turn, pending = [], None, []
    def flush_turn_header(v, sides, ref):
        t = v["turn"]; p = v["current_player"]
        head = f"\n**Turn {t} — {names[p]}**" if t > 0 else "\n**Setup**"
        lines.append(head + f" (points: {names[0]} {sides[0]['points']}, {names[1]} {sides[1]['points']})")
        for s in (0, 1):
            lines.append(f"- {names[s]} hand: {', '.join(ref['hands'][s]) or 'empty'}")
        if t > 0:
            for s in (0, 1):
                lines.append(f"- {names[s]} board: {board_line(sides[s])}")
            en = sides[p]["energy_now"]
            lines.append(f"- {names[p]}'s Energy this turn: {en or 'none'} (next: {sides[p]['energy_next']})")
            if v.get("stadium"): lines.append(f"- Stadium: {card_name(v['stadium'])}")
        lines.append("- Moves:")
        lines.extend(pending); pending.clear()
    step = 0
    while True:
        applied = env.history()
        assert all(applied[i][2] == rec[i][2] for i in range(len(applied))), "replay diverged"
        if env.done: break
        sides, v = views(env)
        if v["turn"] != cur_turn:
            cur_turn = v["turn"]; flush_turn_header(v, sides, json.loads(env.referee()))
        nxt = rec[len(applied)]
        legal = env.legal_actions_json(); idx = [i for i, m in enumerate(legal) if m == nxt[2]]
        assert idx, "move not legal in replay"
        p = nxt[0]; hands_before = json.loads(env.referee())["hands"]
        env.step(idx[0])
        new = env.history()[len(applied):]
        sides_after, _ = views(env)
        ref_after = json.loads(env.referee())
        ch = changes(sides, sides_after, names)
        for j, (pp, src, mv, _v) in enumerate(new):
            m = json.loads(mv)
            if isinstance(m, dict) and "DrawCard" in m:
                drawn = collections.Counter(ref_after["hands"][pp]) - collections.Counter(hands_before[pp])
                pending.append(f"  - {names[pp]} draws " + (", ".join(drawn.elements()) if drawn else f"{m['DrawCard']['amount']} card(s)"))
                continue
            if isinstance(m, dict) and "ResolveAttackRetaliation" in m:
                continue
            lines.append(f"  - {names[pp]} {describe_move(mv, pp, sides, names[pp])}" + (" [forced]" if src == "forced" else ""))
            if isinstance(m, dict):
                k = list(m)[0]; x = m[k]
                card = x.get("evolution") or x.get("trainer_card") or x.get("tool_card") if isinstance(x, dict) else None
                if k == "Place": card = x[0]
                if card: GLOSS.setdefault(card_name(card), card)
        if ch: lines.append("    - what changed: " + "; ".join(ch))
    w, pts, turns = env.result()
    assert (w, list(pts), turns) == (res[0], list(res[1]), res[2]), "replay result differs"
    return lines, (w, list(pts), turns)
