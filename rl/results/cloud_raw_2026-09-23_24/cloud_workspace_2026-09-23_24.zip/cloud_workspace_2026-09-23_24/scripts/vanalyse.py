import json, math, collections, sys
S = sys.argv[1]
lim = json.load(open(f"{S}/lim/limitless_b4a_2026-09-23.json"))["cells"]
def sc(r, deck, pair):
    a, b = pair.split("|")
    if r == "draw": return .5
    win_a = r == "a"
    return float(win_a) if deck == a else float(not win_a)
base = collections.defaultdict(dict)
for l in open(f"{S}/k3table_games.jsonl"):
    g = json.loads(l); base[g["pair"]][g["seed"]] = g["res"]
var = collections.defaultdict(lambda: collections.defaultdict(dict))
for l in open(f"{S}/vtable_games.jsonl"):
    g = json.loads(l); var[g["variant"]][g["pair"]][g["seed"]] = g["res"]
def limscore(deck, opp):
    if f"{deck}|{opp}" in lim: w, l, t = lim[f"{deck}|{opp}"]
    else: l, w, t = lim[f"{opp}|{deck}"]
    n = w + l + t; p = (w + .5*t)/n; return p, 1.96*math.sqrt(p*(1-p)/n), n
out = {}
for v, pairs in sorted(var.items()):
    deck = v.split("_")[0]
    rows = []; md_old = md_new = 0; shifts = []
    for pair, games in sorted(pairs.items()):
        a, b = pair.split("|"); opp = b if a == deck else a
        seeds = [s for s in games if s in base[pair]]
        new = [sc(games[s], deck, pair) for s in seeds]; old = [sc(base[pair][s], deck, pair) for s in seeds]
        pn, po = sum(new)/len(new), sum(old)/len(old)
        d = [x - y for x, y in zip(new, old)]; md = sum(d)/len(d)
        sd = math.sqrt(sum((x-md)**2 for x in d)/(len(d)-1)) if len(d) > 1 else 0
        pl, hl, nl = limscore(deck, opp)
        rows.append((opp, len(seeds), po, pn, md, 1.96*sd/math.sqrt(len(d)), pl, hl))
        md_old += abs(po-pl); md_new += abs(pn-pl); shifts.append(abs(md))
    k = len(rows)
    print(f"== {v}  (games per pairing: {min(r[1] for r in rows)}–{max(r[1] for r in rows)})")
    for opp, n, po, pn, md, h, pl, hl in rows:
        print(f"   vs {opp:9} Sept8 {100*po:5.1f}  variant {100*pn:5.1f}  shift {100*md:+5.1f} ±{100*h:4.1f}   Limitless {100*pl:5.1f} ±{100*hl:4.1f}   miss Sept8 {100*(po-pl):+5.1f} -> variant {100*(pn-pl):+5.1f}")
    print(f"   deck avg: Sept8 {100*sum(r[2] for r in rows)/k:.1f}  variant {100*sum(r[3] for r in rows)/k:.1f}  Limitless {100*sum(r[6] for r in rows)/k:.1f} | avg miss Sept8 {100*md_old/k:.1f} -> variant {100*md_new/k:.1f} | mean |shift| {100*sum(shifts)/k:.1f}")
