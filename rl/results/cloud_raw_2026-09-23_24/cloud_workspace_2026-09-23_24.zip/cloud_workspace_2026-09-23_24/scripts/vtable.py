# Variant lists vs the other seven Sept 8 lists; same seeds as part 1's pairing (72,000,000 + pair*10,000 + i).
import json, sys, os, itertools, multiprocessing as mp
S = os.path.dirname(os.path.abspath(__file__))
DECKS = ["altaria","blaziken","hydreigon","lucario","sceptile","suicune","vespiquen","weezing"]
PAIRS = list(itertools.combinations(DECKS, 2))
VARIANTS = {"altaria_jlng": ("altaria", "variants/altaria_jlng_pmpt44_2026-08-29.txt"),
            "altaria_lanora": ("altaria", "variants/altaria_lanora_blockdragon_2026-09-10.txt"),
            "vespiquen_twidle": ("vespiquen", "variants/vespiquen_twidleurstixx_breakfastclub_2026-09-02.txt"),
            "vespiquen_kovacs": ("vespiquen", "variants/vespiquen_kovacs469_pokebounty_2026-09-14.txt")}
N = 1000
OUT = f"{S}/vtable_games.jsonl"
def path(deck, var):
    base, f = VARIANTS[var]
    return f"{S}/{f}" if deck == base else f"{S}/decks/{deck}.txt"
def play(t):
    from pdl_rl_env import engine_play
    var, k, i = t
    a, b = PAIRS[k]; seed = 72_000_000 + k*10_000 + i; seat_a = i % 2
    d = (a, b) if seat_a == 0 else (b, a)
    w, pts, turns = engine_play(path(d[0], var), path(d[1], var), seed, ("k3", "k3"))
    res = "draw" if w == -1 else ("a" if w == seat_a else "b")
    return {"variant": var, "pair": f"{a}|{b}", "seed": seed, "seat_a": seat_a, "res": res, "points": list(pts), "turns": turns}
if __name__ == "__main__":
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT):
            r = json.loads(l); done.add((r["variant"], r["seed"]))
    tasks = []
    for var, (base, _) in VARIANTS.items():
        for k, (a, b) in enumerate(PAIRS):
            if base in (a, b):
                tasks += [(var, k, i) for i in range(N) if (var, 72_000_000 + k*10_000 + i) not in done]
    tasks.sort(key=lambda t: (t[2], t[0], t[1]))
    with open(OUT, "a") as f, mp.get_context("spawn").Pool(2) as pool:
        for r in pool.imap_unordered(play, tasks, chunksize=8):
            f.write(json.dumps(r) + "\n"); f.flush()
    print("done")
