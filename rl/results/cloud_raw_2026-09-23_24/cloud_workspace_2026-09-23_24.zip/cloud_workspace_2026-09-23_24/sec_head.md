## List refresh (added 2026-09-24): do real top-finishing lists close the Altaria, Sceptile and Vespiquen misses?

Lists were pulled from Limitless decklist pages; Njord's Sceptile and preluxe's Altaria were cross-checked against the tournament API's standings JSON. Event dates are from the API. Every card number was checked against `lib/card.py`, and every list is 20 cards and plays in the engine.

| deck | player, event, date, finish | vs the Sept 8 list |
|---|---|---|
| Sceptile | Ridz, PMPT #44, Aug 29, 4th/378 | identical |
| Sceptile | LiquidHunter, The Dark League, Sep 2, 1st/77 | identical |
| Sceptile | Nagetto_Zuki, Umbreon99's Manic Monday, Sep 7, 6th/230 | identical |
| Sceptile | Sora Aoi, PokeBounty Showdown #2NA, Sep 14, 2nd/142 | identical |
| Sceptile | Semant1c, Breakfast Club Daily, Sep 14, 1st/79 | identical |
| Sceptile | Njord, PMPT #47, Sep 19, 2nd/295 | identical |
| Altaria | JLNG, PMPT #44, Aug 29, 2nd/378 | −1 Field Blower, +1 Cyrus |
| Altaria | LaNora, Block Dragon, Sep 10, 1st/150 | −1 Swablu, +1 Igglybuff; −1 Field Blower, +1 Cyrus |
| Altaria | itachi1820, PMPT #46, Sep 12, 1st/355 | identical |
| Altaria | preluxe, PMPT #47, Sep 19, 5th/295 | identical |
| Vespiquen | TwidleUrStixx, Breakfast Club x Knowtice, Sep 2, 1st/80 | +1 Vespiquen (A2 018), −1 X Speed |
| Vespiquen | Javiercazorla, Umbreon99's Manic Monday, Sep 7, 10th/230 | identical |
| Vespiquen | kovacs469, PokeBounty Showdown #2NA, Sep 14, 10th/142 | Combee A2a 004 for B4 010; +Minior, +Lucky Ice Pop, +Elegant Cape; −1 Copycat, −1 X Speed, −1 Field Blower |

Only the four lists that differ were simulated: each against the other seven Sept 8 lists, k3 vs k3, 1,000 games per pairing on part 1's exact seeds (72,000,000 + pairing × 10,000 + i), 28,000 games in all.

The files are in `competitive-deck-study-2026-09-08/round-robin-checkpoint/reports/research/decks-variants-2026-09-23/`. It's a sibling folder because k3_screen.py and the jev experiment scripts read every .txt in `research/decks/`.

SHA-256: altaria_jlng 2e2907fd39903531…, altaria_lanora 9f44e70dc83eb07e…, vespiquen_twidleurstixx 85419edbebfc6637…, vespiquen_kovacs469 d45ee3b96c9edaa2….

The paired 95% range on each list-vs-list change is about ±3–4 points.
