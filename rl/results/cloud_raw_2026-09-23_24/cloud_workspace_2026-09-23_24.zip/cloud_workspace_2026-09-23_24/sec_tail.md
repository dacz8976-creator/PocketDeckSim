
- **The misses survive every real list.** Across the four variant lists, the simulator's numbers move 2–4 points per matchup on average. The largest single move is LaNora's Altaria vs Vespiquen, −12.7. The deck-level gaps stay: Altaria 45–47 in the sim against 54.0 real; Vespiquen 47–49 against 56.5. Sceptile's top lists haven't changed at all.
- **Among top-finishing lists, list drift is ruled out** as the explanation for the Altaria, Sceptile and Vespiquen misses. It isn't ruled out that the average Limitless entrant plays different lists from the top finishers.
- **What's left:** how k3 plays these decks; rules errors in cards specific to these decks; or effects in the Limitless population (skill, match format). The Sceptile–Vespiquen reversal (sim 66–34 for Sceptile, real 33–67) is the sharpest single target.

