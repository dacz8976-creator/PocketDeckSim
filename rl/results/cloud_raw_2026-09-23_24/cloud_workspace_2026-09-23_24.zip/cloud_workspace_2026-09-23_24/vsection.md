
**Altaria** (score of Altaria, %)

| opponent | Sept 8 list | jlng | lanora | Limitless |
|---|---:|---:|---:|---:|
| blaziken | 58.3 | 56.3 | 55.9 | 74.2 |
| hydreigon | 57.0 | 59.8 | 55.1 | 57.0 |
| lucario | 56.0 | 55.1 | 62.8 | 71.9 |
| sceptile | 38.3 | 36.9 | 38.2 | 49.1 |
| suicune | 39.0 | 36.5 | 39.1 | 52.3 |
| vespiquen | 43.1 | 39.5 | 30.4 | 38.8 |
| weezing | 37.5 | 34.8 | 34.8 | 34.8 |
| **average of 7** | **47.0** | **45.6** | **45.2** | **54.0** |

**Vespiquen** (score of Vespiquen, %)

| opponent | Sept 8 list | twidle | kovacs | Limitless |
|---|---:|---:|---:|---:|
| altaria | 56.9 | 55.6 | 58.1 | 61.3 |
| blaziken | 22.5 | 23.4 | 26.6 | 18.6 |
| hydreigon | 70.1 | 66.9 | 71.7 | 61.6 |
| lucario | 34.3 | 33.7 | 34.5 | 30.7 |
| sceptile | 33.9 | 31.2 | 34.3 | 66.9 |
| suicune | 54.0 | 49.9 | 47.8 | 73.0 |
| weezing | 68.8 | 66.6 | 69.8 | 83.5 |
| **average of 7** | **48.6** | **46.8** | **49.0** | **56.5** |
